package com.tammamkhalaf.facebookv2.ui.main;

import com.tammamkhalaf.facebookv2.pojo.PostModel;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel

public class PostViewModel extends ViewModel {
    MutableLiveData<List<PostModel>> postsMutableLiveData = new MutableLiveData<List<PostModel>>();

    public void getPosts(){}
}
